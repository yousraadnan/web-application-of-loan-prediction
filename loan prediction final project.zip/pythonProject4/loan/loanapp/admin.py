from django.contrib import admin
from .models import LoanApplication  # Replace with your actual model name

# Register your models here
admin.site.register(LoanApplication)
# Register your models here.
